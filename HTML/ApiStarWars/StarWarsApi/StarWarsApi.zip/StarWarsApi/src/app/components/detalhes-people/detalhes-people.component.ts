import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detalhes-people',
  templateUrl: './detalhes-people.component.html',
  styleUrls: ['./detalhes-people.component.scss']
})
export class DetalhesPeopleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
