package br.com.projetosaula.primeiroprojetospring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeiroProjetoSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
