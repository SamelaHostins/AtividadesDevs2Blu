import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalhesPeopleComponent } from './detalhes-people.component';

describe('DetalhesPeopleComponent', () => {
  let component: DetalhesPeopleComponent;
  let fixture: ComponentFixture<DetalhesPeopleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DetalhesPeopleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DetalhesPeopleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
