package br.com.projetosaula.springprojetoturmas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProjetoTurmasApplicationTests {

	@Test
	void contextLoads() {
	}

}
