#INSERT INTO pessoa (nome, idade, endereco, sexo) VALUES ('Ramon', 32, 'Hermann Spernau', 'M');
#INSERT INTO pessoa (nome, idade, endereco, sexo) VALUES ('Cecilia', 20, 'Engenherio Odebrecht', 'F');
#INSERT INTO pessoa (nome, idade, endereco, sexo) VALUES ('Camila', 21, 'XV de Novembro', 'F');
#INSERT INTO pessoa (nome, idade, endereco, sexo) VALUES ('Professora', 35, 'Stanislau Schaette', 'F');

#INSERT INTO professor (pessoa_id) VALUES (4);

#INSERT INTO aluno (ano, pessoa_id) VALUES (5, 1);
#INSERT INTO aluno (ano, pessoa_id) VALUES (5, 2);
#INSERT INTO aluno (ano, pessoa_id) VALUES (6, 3);

#INSERT INTO turma(nome, periodo, max_alunos, professor_id) VALUES ('Turma 1', 'Matutino', 20, 1);
#INSERT INTO turma(nome, periodo, max_alunos, professor_id) VALUES ('Turma 2', 'Vespertino', 20, 1);
#INSERT INTO turma(nome, periodo, max_alunos, professor_id) VALUES ('Turma 3', 'Noturno', 20, 1);