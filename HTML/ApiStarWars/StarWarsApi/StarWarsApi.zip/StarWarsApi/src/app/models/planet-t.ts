export class PlanetT {
  climate?: string;
  name?: string;
  population?: string;
  terrain?: string;
  gravity?: string;
  diameter?: string;


  constructor(object: Partial<PlanetT>){
    Object.assign(this, object);
      }

}
