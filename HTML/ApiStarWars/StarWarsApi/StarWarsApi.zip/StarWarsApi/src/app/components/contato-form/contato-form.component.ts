import { PlanetService } from './../../services/planet.service';
import { PlanetT } from './../../models/planet-t';
import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';

@Component({
  selector: 'contato-form',
  templateUrl: './contato-form.component.html',
  styleUrls: ['./contato-form.component.scss']
})
export class ContatoFormComponent implements OnInit {

  formContato: PlanetT = {};

  showForm = new Subject<boolean>();

  planetaInput:string = '';
  numero:number=0;


  constructor(private starService: PlanetService) { }

  ngOnInit(): void {
  }

  getPlaneta( ){
     this.starService.getAllPlanets(this.numero)
      .subscribe(
        (ViaApiStar) => {
          console.log(ViaApiStar);
          this.formContato = ViaApiStar;
          this.showForm.next(true);
        }
      );
  }

}
