export const environment = {
  production: true,
  urlApiStarWars: 'https://swapi.dev/api/planets',
  urlApiStarWarsPessoa: 'https://swapi.dev/api/pessoa'
};
