import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aluno-save',
  templateUrl: './aluno-save.component.html',
  styleUrls: ['./aluno-save.component.scss']
})
export class AlunoSaveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
