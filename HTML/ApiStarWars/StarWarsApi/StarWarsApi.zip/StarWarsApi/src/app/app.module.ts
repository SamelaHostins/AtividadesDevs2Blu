import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PlanetComponent } from './components/planet/planet.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { ContatoFormComponent } from './components/contato-form/contato-form.component';
import { HomeComponent } from './components/home/home.component';
import { DetalhesComponent } from './components/detalhes/detalhes.component';
import { ColumComponent } from './components/colum/colum.component';
import { PeopleComponent } from './components/people/people.component';
import { DetalhesPeopleComponent } from './components/detalhes-people/detalhes-people.component';
import { ContatoFormPeopleComponent } from './components/contato-form-people/contato-form-people.component';


@NgModule({
  declarations: [
    AppComponent,
    PlanetComponent,
    HeaderComponent,
    FooterComponent,
    ContatoFormComponent,
    HomeComponent,
    DetalhesComponent,
    ColumComponent,
    PeopleComponent,
    DetalhesPeopleComponent,
    ContatoFormPeopleComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
