import { PlanetService } from './../../services/planet.service';
import { PlanetT } from './../../models/planet-t';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-planet',
  templateUrl: './planet.component.html',
  styleUrls: ['./planet.component.scss']
})
export class PlanetComponent implements OnInit {
  private planet!:PlanetT;
  numeroPagina:number = 1;
  constructor( private PlanetService: PlanetService) { }

  ngOnInit(): void{


  }

  loadPlanet() {
    this.PlanetService.getAllPlanets(this.numeroPagina)
                      .subscribe((data: PlanetT) => {
                        this.planet = data;
                      });
  }

}
