export class Aluno {
}
