export class Professor {
}
