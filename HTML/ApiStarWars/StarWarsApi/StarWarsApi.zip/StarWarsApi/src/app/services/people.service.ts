import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { PeopleT } from '../models/people-t';

@Injectable({
  providedIn: 'root'
})
export class PeopleService {

  readonly endpoint = 'https://swapi.dev/api/people/1/';

  constructor(private http: HttpClient) { }

  //Metódo que chama todos os planetas
  getAllPeople(numeroPessoa: number) {
    const urlGet=`${environment.urlApiStarWarsPessoa}/${numeroPessoa}/`;
    return this.http.get<PeopleT>(urlGet);
  }
}

