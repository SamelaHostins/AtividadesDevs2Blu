import { PeopleT } from './people-t';

describe('People', () => {
  it('should create an instance', () => {
    expect(new PeopleT({})).toBeTruthy();
  });
});
