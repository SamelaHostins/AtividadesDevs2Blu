import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { PeopleT } from 'src/app/models/people-t';
import { PeopleService } from 'src/app/services/people.service';

@Component({
  selector: 'app-contato-form-people',
  templateUrl: './contato-form-people.component.html',
  styleUrls: ['./contato-form-people.component.scss']
})
export class ContatoFormPeopleComponent implements OnInit {

  formContato: PeopleT = {};

  showForm = new Subject<boolean>();

  peopleInput:string = '';
  numero:number=0;


  constructor(private starService2: PeopleService) { }

  ngOnInit(): void {
  }

  getPeople( ){
     this.starService2.getAllPeople(this.numero)
      .subscribe(
        (ViaApiStar) => {
          console.log(ViaApiStar);
          this.formContato = ViaApiStar;
          this.showForm.next(true);
        }
      );
  }
}
