package br.com.projetosaula.springprojetoturmas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import br.com.projetosaula.springprojetoturmas.entity.Aluno;
import br.com.projetosaula.springprojetoturmas.entity.Pessoa;
import br.com.projetosaula.springprojetoturmas.entity.Professor;
import br.com.projetosaula.springprojetoturmas.repository.AlunoRepository;
import br.com.projetosaula.springprojetoturmas.repository.PessoaRepository;
import br.com.projetosaula.springprojetoturmas.repository.ProfessorRepository;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/professor")
public class ProfessorController {

	@Autowired
	// Faz uma comunicação entgre o banco e o back
	ProfessorRepository professorRepository;

	@Autowired
	// Faz uma comunicação entre o banco e o back
	PessoaRepository pessoaRepository;

	@GetMapping
	public List<Professor> getAll() {
		return professorRepository.findAll();
	}

	@PostMapping
	@ResponseStatus(code = HttpStatus.CREATED)
	public ResponseEntity<Professor> addProfessor(@RequestBody Professor professor) throws Exception {

		//precisa ser nulo pois o id será incrementado automaticamente
		if (professor.getPessoa().getId() == null) {
			Pessoa pessoaProfessor = pessoaRepository.save(professor.getPessoa());
			professor.setPessoa(pessoaProfessor);
		}else {
			//estou verificando se existe o id
			Pessoa pessoaVerificacao = pessoaRepository.findById(professor.getPessoa().getId())
					.orElseThrow(() -> new Exception("Pessoa não existe"));
			professor.setPessoa(pessoaVerificacao);
		}
		Professor professorResponse = professorRepository.save(professor);
		return new ResponseEntity<Professor>(professorResponse, HttpStatus.CREATED);

	}

}
