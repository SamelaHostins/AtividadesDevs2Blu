import { environment } from './../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PlanetT } from '../models/planet-t';

@Injectable({
  providedIn: 'root'
})
export class PlanetService {

  readonly endpoint = 'https://swapi.dev/api/planets/1/';

  constructor(private http: HttpClient) { }

  //Metódo que chama todos os planetas
  getAllPlanets(numeroPlaneta: number) {
    const urlGet=`${environment.urlApiStarWars}/${numeroPlaneta}/`;
    return this.http.get<PlanetT>(urlGet);
  }
}
