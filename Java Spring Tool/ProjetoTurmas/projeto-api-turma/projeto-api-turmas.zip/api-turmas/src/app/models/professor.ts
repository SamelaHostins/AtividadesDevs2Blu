import { Pessoa } from './pessoa';
export class Professor {
  id?: number;
  turma?: string;
  pessoa?: Pessoa;
}
