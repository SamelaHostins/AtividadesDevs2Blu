import { PeopleService } from './../../services/people.service';
import { Component, OnInit } from '@angular/core';
import { PeopleT } from 'src/app/models/people-t';

@Component({
  selector: 'app-people',
  templateUrl: './people.component.html',
  styleUrls: ['./people.component.scss']
})
export class PeopleComponent implements OnInit {

  private people!:PeopleT;
  numeroPagina:number = 1;
  constructor( private PeopleService: PeopleService) { }

  ngOnInit(): void{

  }

  loadPeople() {
    this.PeopleService.getAllPeople(this.numeroPagina)
                      .subscribe((data: PeopleT) => {
                        this.people = data;
                      });
  }
}
