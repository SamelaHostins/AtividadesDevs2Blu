import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContatoFormPeopleComponent } from './contato-form-people.component';

describe('ContatoFormPeopleComponent', () => {
  let component: ContatoFormPeopleComponent;
  let fixture: ComponentFixture<ContatoFormPeopleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContatoFormPeopleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContatoFormPeopleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
