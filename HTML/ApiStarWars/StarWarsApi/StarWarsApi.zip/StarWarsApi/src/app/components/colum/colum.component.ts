import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-colum',
  templateUrl: './colum.component.html',
  styleUrls: ['./colum.component.scss']
})
export class ColumComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
