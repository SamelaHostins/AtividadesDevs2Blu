/*INSERT INTO GENERO(descricao) VALUES ('Aventura');
INSERT INTO GENERO(descricao) VALUES ('Fantasia');
INSERT INTO GENERO(descricao) VALUES ('Ficção');
INSERT INTO GENERO(descricao) VALUES ('Drama');
INSERT INTO GENERO(descricao) VALUES ('Ação');
INSERT INTO GENERO(descricao) VALUES ('Romance');

INSERT INTO RESTRICAO(descricao, idade) VALUES ('Livre', 0);
INSERT INTO RESTRICAO(descricao, idade) VALUES ('10 anos', 0);
INSERT INTO RESTRICAO(descricao, idade) VALUES ('12 anos', 0);
INSERT INTO RESTRICAO(descricao, idade) VALUES ('14 anos', 0);
INSERT INTO RESTRICAO(descricao, idade) VALUES ('16 anos', 0);
INSERT INTO RESTRICAO(descricao, idade) VALUES ('18 anos', 0);
*/
*\
INSERT INTO FILME(titulo, genero_id, restricao_id, favoritos) VALUES ('Gente Grande',2, 1 ,1);