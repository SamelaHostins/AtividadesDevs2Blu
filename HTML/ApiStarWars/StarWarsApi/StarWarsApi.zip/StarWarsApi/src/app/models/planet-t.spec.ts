import { PlanetT } from './planet-t';

describe('PlanetT', () => {
  it('should create an instance', () => {
    expect(new PlanetT({})).toBeTruthy();
  });
});
