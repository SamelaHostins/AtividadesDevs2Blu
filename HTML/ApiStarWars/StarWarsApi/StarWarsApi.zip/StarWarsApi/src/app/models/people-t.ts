export class PeopleT {
  name?: string;
  height?: string;
  gender?: string;
  mass?: string;
  hair_color?: string;
  eye_color?: string


  constructor(object: Partial<PeopleT>){
    Object.assign(this, object);
      }

}


